export const addTask = (req, res) => {
  res.json('from controller');
};
