export const register = (req, res) => {};
export const login = (req, res) => {};
export const logout = (req, res) => {};
