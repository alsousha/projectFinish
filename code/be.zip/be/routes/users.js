import express from 'express';
import { addTask } from '../controllers/task.js';

const router = express.Router();

export default router;
